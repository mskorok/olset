"use strict";

angular.module('app.layout').controller('HeaderCtrl', function ($scope, $window, $state, User, Auth, $location) {
	
	//console.log($window.localStorage.getItem('userData'));

	$scope.$watch(Auth.userHaveRole, function (value, oldValue) {
		console.log('roleValueW: ',value);
		$scope.userRole = value;
	    if(value) {
		  	if(value == 'Manager') {
			  	$scope.isManager = true;
		  	} else if (value == 'User') {
			  	$scope.isUser = true;
		  	} else if (value == 'Administrator') {
			  	$scope.isAdmin = true;
		  	}
			console.log('the val: ', value);
		  
	    } else {
		    
		    $scope.userRole = false;
		    
	    }

    }, true);
    
	//console.log('Role: ',Auth.userHaveRole);
	
	$scope.userLogout = function () {
		
		$window.localStorage.removeItem("authToken");
		$window.localStorage.removeItem("userData");
		
		$state.go('realLogin'); 
		
	}
	
		
})
