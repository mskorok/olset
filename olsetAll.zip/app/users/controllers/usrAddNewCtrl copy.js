angular.module('app.users').controller('usrAddNewCtrl', function ($scope, $http, $window, $state) {
	
	$scope.userRegistrationData = {
		'name' : '',
		'username' : '',
		'email' : '',
		'department' : '',
		'role' : '',
		'password' : '',
 	}
 	
 	
 	
	$scope.UserRegistration = function() { 
		
		console.log($scope.userRegistrationData.role);


		var dataall = {
			"firstName":$scope.userRegistrationData.name,
			"username":$scope.userRegistrationData.username,
			"email":$scope.userRegistrationData.email,
			"password":$scope.userRegistrationData.password
		}
		
		var ordata = JSON.stringify(dataall);
		
		
		var authToken = $window.localStorage.getItem('authToken');
		console.log(authToken);
		if ($scope.userRegistrationData.role == 'manager') {
			
			$http({
			    method: 'POST',
			    url: 'http://144.76.5.203/olsetapp/users/createManager',
			    //data: "message=" + message,
			    headers: {
				    'Authorization': 'Bearer '+authToken,
				    'Content-Type': 'application/json'
				},
				
				data: {
					
			"firstName":$scope.userRegistrationData.name,
			"LastName": "YOLO",
			"username":$scope.userRegistrationData.username,
			"email":$scope.userRegistrationData.email,
			"password":$scope.userRegistrationData.password
				}
			    
			}).then(function successCallback(response) {
				
				console.log(response);
	
			}, function errorCallback(response) {
	
				console.log('YOYO');
				console.warn(response);
	
			});
				
		} else if($scope.userRegistrationData.role == 'user') {
			
			$http({
			    method: 'POST',
			    url: 'http://144.76.5.203/olsetapp/users/createUser',
			    //data: "message=" + message,
			    headers: {
				    'Authorization': 'Bearer '+authToken,
				    'Content-Type': 'application/json'
				},
				
				data: {
					ordata
				}
			    
			}).then(function successCallback(response) {
				
				console.log(response);
	
			}, function errorCallback(response) {
	
				console.log('YOYO');
				console.warn(response);
	
			});
		
		} else {
			
			console.log('Please select a role');
			
		}

	}
 	
 	
})