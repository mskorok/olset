angular.module('app.users').controller('usrAddNewCtrl', function ($scope, $http, $window, $state, MainConf) {
	
	$scope.userRegistrationData = {
		'name' : '',
		'username' : '',
		'email' : '',
		'department' : '',
		'role' : '',
		'password' : '',
 	}
 	
 	
 	
	$scope.UserRegistration = function() { 
		
		console.log($scope.userRegistrationData.role);



		

			
			$http({
			    method: 'POST',
			    url: MainConf.servicesUrl()+'users/createUserPublic',
			    //data: "message=" + message,
			    headers: {
				    'Content-Type': 'application/json'
				},
				
				data: {
					
					"firstName":$scope.userRegistrationData.name,
					"username":$scope.userRegistrationData.username,
					"email":$scope.userRegistrationData.email,
					"password":$scope.userRegistrationData.password,
					"organization":1
				}
			    
			}).then(function successCallback(response) {
					$scope.userRegistrationData = {
						'name' : '',
						'username' : '',
						'email' : '',
						'department' : '',
						'role' : '',
						'password' : '',
				 	}
				console.log(response);
//console.log("del: ",response);
						var code = response.data.data.code;
						var title = (code == 1)? "SUCCESS" : "ERROR";
						var color = (code == 1)? "#739E73" : "#d81e1e";
						var icon = (code == 1)? "fa fa-check" : "fa fa-exclamation-triangle";
						
						//Error Logs
				        $.bigBox({
				            title: title,
				            content: response.data.data.status,
				            color: color,
				            timeout: 15000,
				            icon: icon,
				            number: "1"
				        });
				$state.go('app.users.addnew');
	
			}, function errorCallback(response) {
	
				console.log('YOYO');
				console.warn(response);
	
			});
				

			


	}
 	
 	
})